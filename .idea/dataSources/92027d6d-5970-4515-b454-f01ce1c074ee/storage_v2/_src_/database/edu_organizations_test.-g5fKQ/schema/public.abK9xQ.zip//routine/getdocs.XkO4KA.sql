CREATE FUNCTION getdocs(doc_id uuid, err_code text)
  RETURNS SETOF vuz_doc
LANGUAGE plpgsql
AS $$
BEGIN
return query select v.* from gisun_export_info as g
join vuz_doc as v 
on g.doc = v.id where v.edu_org = doc_id and g.error_code=err_code;
END;
$$;

